package com.devstack.productserviceapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
